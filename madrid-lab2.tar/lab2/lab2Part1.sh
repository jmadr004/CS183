#!/bin/sh
#lab 2 part 1 finding how many times the word magic appears in lines of code from the linux kernel
#source tree, regardless of wether the word is upper case, lower case, or some combination,
#only counting instance of files ending with a .h extension

grep -Ri --include=\*.h /usr/src/kernels -e 'magic'| wc -l
