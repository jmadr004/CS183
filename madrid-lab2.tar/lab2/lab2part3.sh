#!/bin/bash
#lab2 part3 monitor a file continously and write to a log file depending on the success of the 
#operation. If the program does not recieve a successful check it should add an entry to a log file
#/var/log/cs183/uptime.log format 04-09-19 15:31:55 - File "/full/path/to/lab2-test" has been lost
#or 04-09-19 15:33:55 - File "/full/path/to/lab2-test" has been found

FILE=/lab2/lab2-test
log_path=/var/log/cs183/uptime.log
NOW=$(date +"%m-%d-%Y %T")
#echo "$NOW"
if [ -f $FILE ]
 then
  echo "$NOW" "-File" '"/lab2/lab2-test"' "has been found" >> $log_path
else
  echo "$NOW" "-File" '"/lab2/lab2-test"' "has been lost" >> $log_path
fi

