#!/bin/bash
#lab2 part 2 enumerates the systems users and groups from /etc/passwd and /etc/group
#print each users login, uid, and groups

user=($(awk -F: '{print $1}' /etc/passwd))
userID=($(awk -F: '{print $3}' /etc/passwd))
userGID=($(awk -F: '{print $4}' /etc/passwd))
groupID=($(awk -F: '{print $1}' /etc/group))
groupGID=($(awk -F: '{print $3}' /etc/group))
counter=0
counterG=0
for x in ${userGID[@]}
do
	counterG=0
	for y in ${groupGID[@]}
	do
		if [ $x -eq $y ]
		then
		   #echo "${groupID[$counterG]}"
 		   userGID[$counter]=${groupID[$counterG]}
		   #echo "${userGID[$counter]}"
		fi
		counterG=$((counterG+1))
	done
echo "${user[$counter]}" " ${userID[$counter]}" " ${userGID[$counter]}"
counter=$((counter+1))
done


