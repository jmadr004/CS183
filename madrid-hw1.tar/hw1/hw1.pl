#!/usr/bin/perl
#www.tizag.com/perlT/perluserinput.php
#www.perlmaven.com/argv-in-perl
#www.perlmaven.com/the-diamond-operator the answer AWESOME:

if(@ARGV){
	while(<>){
		print;
	}
}
