#!/bin/bash
#homework 1 bash file, simple way to print to screen using cat, take in user input and loop through 
#the input and print to screen using cat

for x in $@
do 
  cat $x
done
