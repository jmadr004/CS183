#!/usr/bin/python
#homework 1 print out user input using python code
#

import sys
if len(sys.argv) >1:
	for f in sys.argv[1:]:
		with open(f, 'r') as files:
			print files.read()
